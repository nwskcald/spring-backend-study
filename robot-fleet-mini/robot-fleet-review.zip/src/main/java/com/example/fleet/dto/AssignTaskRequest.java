package com.example.fleet.dto;

public class AssignTaskRequest{

    private String robotNumber;
    private String taskNumber;

    public AssignTaskRequest(
        String robotNumber, String taskNumber
    ){
        this.robotNumber = robotNumber;
        this.taskNumber = taskNumber;
    }

    public AssignTaskRequest(){
    }

    public String getRobotNumber(){
        return robotNumber;
    }

    public String getTaskNumber(){
        return taskNumber;
    }

    public void setRobotNumber(String robotNumber){
        this.robotNumber = robotNumber;
    }

    public void setTaskNumber(String taskNumber){
        this.taskNumber = taskNumber;
    }
}